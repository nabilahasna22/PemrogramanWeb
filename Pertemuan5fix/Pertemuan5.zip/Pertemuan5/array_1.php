<!DOCTYPE html>
<html>
<head>

</head>
<body>
<h2>Array Terindeks</h2>
<?php
$Listdosen=["Elok Nur Hamdana","Unggul Pamenang","Bagas Nugraha",];

foreach ($Listdosen as $dosen) {
    echo $dosen . "<br>";
}
?>
</body>
</html>
