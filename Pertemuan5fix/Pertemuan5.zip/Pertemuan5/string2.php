<?php

echo "Baris\nbaru <br>";
echo "Baris\nbaru <br>";
echo "Halo\rDunia <br>";
echo "Baris\rDunia <br>";

echo "<pre>Halo\tDunia!</pre>";
echo '<pre>Halo\tDunia!</pre>';

echo "Katakanlah\"Tidak Pada Narkoba!\"<br>";
echo 'Katakanlah\'Tidak Pada Narkoba!\'<br>';

?>

