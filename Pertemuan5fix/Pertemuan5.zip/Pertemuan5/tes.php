<?php

$nama=@$_GET['nama'];
$usia=@$_GET['usia'];

echo "Halo {$nama}! Apakah benar anda berusia {$usia}tahun ?";
?>
