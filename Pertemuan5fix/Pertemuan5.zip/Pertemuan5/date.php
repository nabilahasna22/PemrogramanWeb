<!DOCTYPE html>
<html>
    <head>
    </head>

    <body>
        <h3>Date</h3>
        <?php
        echo " Today is".date("y/m/d")."<br>";
        echo " Today is".date("y.m.d")."<br>";
        echo " Today is".date("y-m-d")."<br>";
        echo " Today is".date("l")."<br>";
        ?>
    </body>
</html>